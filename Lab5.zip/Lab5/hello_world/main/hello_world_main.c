#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/timers.h"

typedef struct
{
    const char *msg;   // chuỗi cần in
    int max_count;     // in tối đa bao nhiêu lần
    int count;         // đã in được bao nhiêu lần
} timer_info_t;

TimerHandle_t timer1 = NULL;
TimerHandle_t timer2 = NULL;

timer_info_t timer1_info = {
    .msg = "ahihi",
    .max_count = 10,
    .count = 0
};

timer_info_t timer2_info = {
    .msg = "ihaha",
    .max_count = 5,
    .count = 0
};

// Callback dùng chung cho cả 2 timer
void ATimerCallback( TimerHandle_t xTimer )
{
    // Lấy con trỏ info của timer này
    timer_info_t *info = (timer_info_t *) pvTimerGetTimerID(xTimer);
    if (info == NULL) return;

    info->count++;
    printf("%s (count = %d)\n", info->msg, info->count);

    // Nếu đã đủ số lần thì dừng timer
    if (info->count >= info->max_count)
    {
        xTimerStop(xTimer, 0);   // không chờ tick
    }
}

void app_main(void)
{
    // Tạo timer 1: chu kỳ 2 giây, auto-reload
    timer1 = xTimerCreate(
        "Timer1",                  // tên
        pdMS_TO_TICKS(2000),       // period = 2000 ms
        pdTRUE,                    // auto-reload
        (void *)&timer1_info,      // ID: trỏ tới struct info
        ATimerCallback             // callback
    );

    // Tạo timer 2: chu kỳ 3 giây, auto-reload
    timer2 = xTimerCreate(
        "Timer2",
        pdMS_TO_TICKS(3000),       // 3000 ms
        pdTRUE,
        (void *)&timer2_info,
        ATimerCallback
    );

    if (timer1 == NULL || timer2 == NULL)
    {
        printf("Cannot create timers!\n");
        return;
    }

    // Start 2 timer (không block, xTicksToWait = 0)
    xTimerStart(timer1, 0);
    xTimerStart(timer2, 0);

    // app_main là một task trong FreeRTOS rồi,
    // không cần vTaskStartScheduler trong ESP-IDF.
    while (1)
    {
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}